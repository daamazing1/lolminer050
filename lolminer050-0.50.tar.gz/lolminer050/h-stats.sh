#!/usr/bin/env bash

#######################
# MAIN script body
#######################

[ -t 1 ] && . colors
# can't figure out why curl skips first couple of characters.
stats_raw="{`curl -H "Accept: application/json" -H "Content-Type: application/json" http://127.0.0.1:1003`"
if [[ $? -ne 0 || -z $stats_raw ]]; then
	echo -e "${YELLOW}Failed to read $miner from localhost:1003${NOCOLOR}"
else
	khs=`echo $stats_raw | jq -r '."TotalSpeed(30s)"'`
	local temp=$(jq '.temp' <<< $gpu_stats)
	local fan=$(jq '.fan' <<< $gpu_stats)
	stats=$(jq --argjson temp "$temp" --argjson fan "$fan" \
		'{hs_units: "Sol/s", hs: to_entries|map(select(.key|test("GPU")))|map(.value."Speed(30s)"), algo: .Algorithm, $temp, $fan, ar: [."AcceptedShares(Session)", 0]}' <<< "$stats_raw")
fi
[[ -z $khs ]] && khs=0
[[ -z $stats ]] && stats="null"
